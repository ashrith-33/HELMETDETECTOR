# BikersHelmet > 2022-11-24 11:28am
https://universe.roboflow.com/aiproject-jatqb/bikershelmet

Provided by a Roboflow user
License: CC BY 4.0

